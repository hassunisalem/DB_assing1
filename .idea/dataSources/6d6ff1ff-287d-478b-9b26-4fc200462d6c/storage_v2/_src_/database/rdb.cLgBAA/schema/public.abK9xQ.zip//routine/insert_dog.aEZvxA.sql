create procedure insert_dog(_name character varying, _age integer, _barkpitch character)
    language sql
as
$$
WITH NEW_DOG AS (
              INSERT INTO Pets (species , name, age, liveCount, barkPitch) VALUES ('dog', _name, _age, null, _barkPitch)
            ) SELECT 'dog', _name, _age,null, _barkPitch;
$$;

alter procedure insert_dog(varchar, integer, char) owner to postgres;

