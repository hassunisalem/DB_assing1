create procedure insert_animal(_name character varying, _age integer)
    language sql
as
$$
WITH NEW_ANIMAL AS (
                INSERT INTO Pets (species , name, age) VALUES ('other', _name, _age)
)               SELECT 'other', _name, _age;
$$;

alter procedure insert_animal(varchar, integer) owner to postgres;

