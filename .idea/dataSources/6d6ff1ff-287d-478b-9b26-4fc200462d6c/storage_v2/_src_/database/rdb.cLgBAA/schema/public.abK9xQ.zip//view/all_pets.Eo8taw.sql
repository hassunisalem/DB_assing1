create view all_pets(species, pet_id, name, age, livecount, barkpitch) as
SELECT pets.species,
       pets.pet_id,
       pets.name,
       pets.age,
       pets.livecount,
       pets.barkpitch
FROM pets;

alter table all_pets
    owner to postgres;

