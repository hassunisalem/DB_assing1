create procedure insert_cat(_name character varying, _age integer, _livecount integer)
    language sql
as
$$
WITH NEW_CAT AS (
            INSERT INTO Pets (species , name, age, liveCount, barkPitch) VALUES ('cat', _name, _age, _liveCount, null)
)           SELECT 'cat', _name, _age,_liveCount;
$$;

alter procedure insert_cat(varchar, integer, integer) owner to postgres;

