create view cats(id, name, age, vet_cvr, lifecount) as
SELECT p.id,
       p.name,
       p.age,
       p.vet_cvr,
       c.lifecount
FROM pet_data p
         JOIN cat_data c ON p.id = c.id;

alter table cats
    owner to postgres;

