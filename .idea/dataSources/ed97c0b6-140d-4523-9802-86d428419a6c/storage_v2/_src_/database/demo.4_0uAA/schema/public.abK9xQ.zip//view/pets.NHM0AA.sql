create view pets(id, name, age, vet_cvr, lifecount, barkpitch) as
SELECT p.id,
       p.name,
       p.age,
       p.vet_cvr,
       c.lifecount,
       d.barkpitch
FROM pet_data p
         LEFT JOIN cat_data c ON p.id = c.id
         LEFT JOIN dog_data d ON p.id = d.id;

alter table pets
    owner to postgres;

