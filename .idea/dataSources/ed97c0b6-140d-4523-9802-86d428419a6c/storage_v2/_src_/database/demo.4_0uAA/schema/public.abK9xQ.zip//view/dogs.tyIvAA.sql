create view dogs(id, name, age, vet_cvr, barkpitch, dog_age) as
SELECT p.id,
       p.name,
       p.age,
       p.vet_cvr,
       d.barkpitch,
       7 * p.age AS dog_age
FROM pet_data p
         JOIN dog_data d ON p.id = d.id;

alter table dogs
    owner to postgres;

